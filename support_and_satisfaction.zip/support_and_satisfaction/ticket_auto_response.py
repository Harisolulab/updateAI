import os
from dotenv import load_dotenv

from langchain_community.chat_models import ChatOpenAI
from langchain_openai import ChatOpenAI, OpenAIEmbeddings
from langchain_community.vectorstores import FAISS

from langchain.schema import HumanMessage, SystemMessage
from langchain.text_splitter import CharacterTextSplitter

# Load environment variables from .env
load_dotenv()
api_key = os.getenv("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")

# Initialize GPT-4o chat model with API key
llm = ChatOpenAI(model="gpt-4o", temperature=0)
# Prepare FAQ and historical ticket data (replace with your real data or database)
faq_texts = [
    {"question": "What is the status of my order?", "answer": "You can track your order using the tracking link emailed to you."},
    {"question": "How do I return an item?", "answer": "Returns are accepted within 30 days via our returns portal."},
    {"question": "What shipping options do you offer?", "answer": "We offer standard, expedited, and overnight shipping options."},
    {"question": "How can I update my account details?", "answer": "Log in and go to 'Account Settings' to update your details."},
    {"question": "What is the product warranty?", "answer": "Most products come with a one-year warranty. Check specific terms per product."},
]

# Prepare documents for vector store
docs = [f"Q: {faq['question']}\nA: {faq['answer']}" for faq in faq_texts]

# Split documents into chunks for better indexing
text_splitter = CharacterTextSplitter(chunk_size=300, chunk_overlap=20)
texts = []
for doc in docs:
    texts.extend(text_splitter.split_text(doc))

# Initialize embeddings with API key
embedding = OpenAIEmbeddings()

# Create FAISS vector store from embedded texts
vector_store = FAISS.from_texts(texts, embedding)

# Function to classify user intent
def classify_intent(user_query: str) -> str:
    prompt = f"""Classify the intent of this user query into one of these labels:
order_status, return_policy, shipping_info, account_details, product_info, unknown.

Query: "{user_query}"

Respond with only the intent label."""
    response = llm.invoke([SystemMessage(content=prompt), HumanMessage(content=user_query)])
    intent = response.content.strip().lower()
    if intent not in [
        "order_status",
        "return_policy",
        "shipping_info",
        "account_details",
        "product_info",
    ]:
        intent = "unknown"
    return intent

# Function to generate response based on intent and vector search
def generate_response(user_query: str) -> str:
    intent = classify_intent(user_query)
    if intent == "unknown":
        return "Sorry, I couldn't understand your query clearly. Please rephrase or contact support."

    # Retrieve relevant FAQ snippets using vector similarity search
    similar_docs = vector_store.similarity_search(user_query, k=3)
    context = "\n".join([doc.page_content for doc in similar_docs])

    # Compose prompt to GPT-4o to generate an accurate answer
    prompt = f"""
You are a helpful customer support AI. Use the context below to answer the question precisely.

Context:
{context}

Question:
{user_query}

Answer:
"""
    response = llm.invoke([SystemMessage(content=prompt), HumanMessage(content=user_query)])
    return response.content.strip()
# Example usage
if __name__ == "__main__":
    queries = [
        "Can you update me on my order status?",
        "How do I return an item I purchased?",
        "What shipping methods are available?",
        "I want to know about product warranty.",
        "How do I change my account info?",
        "What is your refund policy?",
    ]
    for q in queries:
        print(f"User: {q}")
        print("AI:", generate_response(q))
        print("-" * 40)

